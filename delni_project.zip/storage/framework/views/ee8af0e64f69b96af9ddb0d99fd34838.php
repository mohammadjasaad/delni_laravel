<footer class="bg-yellow-400 text-black py-6 mt-10">
    <div class="max-w-7xl mx-auto px-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
        <div>
            <h3 class="text-lg font-bold mb-2">Delni.co</h3>
            <img src="/logo.png" alt="Delni Logo" class="w-12 h-12 mb-2">
            <p>منصتك الأفضل للإعلانات المبوبة في سوريا</p>
        </div>

        <div>
            <h4 class="font-bold mb-2">روابط سريعة</h4>
            <ul class="space-y-1">
                <li><a href="<?php echo e(url('/')); ?>" class="hover:underline"><?php echo e(__('messages.home')); ?></a></li>
                <li><a href="<?php echo e(route('ads.index')); ?>" class="hover:underline"><?php echo e(__('messages.ads')); ?></a></li>
                <li><a href="<?php echo e(route('dashboard.myads')); ?>" class="hover:underline"><?php echo e(__('messages.my_ads')); ?></a></li>
                <a href="<?php echo e(url('/contact')); ?>" class="hover:underline"><?php echo e(__('messages.contact_us')); ?></a>

            </ul>
        </div>

        <div>
            <h4 class="font-bold mb-2">عن الموقع</h4>
            <p>دلّني هو موقع إعلانات مبوبة مجاني لبيع وشراء العقارات والسيارات بسهولة.</p>
        </div>

        <div>
            <h4 class="font-bold mb-2">تابعنا</h4>
            <ul class="space-y-1">
                <li><a href="#" class="hover:underline">فيسبوك</a></li>
                <li><a href="#" class="hover:underline">إنستغرام</a></li>
                <li><a href="#" class="hover:underline">تيك توك</a></li>
            </ul>
        </div>
    </div>

    <div class="text-center mt-6 text-sm text-black border-t pt-4">
        © 2025 Delni.co - جميع الحقوق محفوظة
    </div>
</footer>
<?php /**PATH /home/delni_user/delni/resources/views/partials/footer.blade.php ENDPATH**/ ?>