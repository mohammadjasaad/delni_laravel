<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-5xl mx-auto px-4 py-8">
        <!-- العنوان -->
        <h1 class="text-2xl font-bold mb-4"><?php echo e($ad->title); ?></h1>

        <!-- الصور -->
            <?php if(is_array($ad->images) && count($ad->images) > 0): ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                <?php $__currentLoopData = $ad->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e(asset('storage/' . $image)); ?>" alt="Ad Image" class="w-full h-48 object-cover rounded">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <img src="/placeholder.png" alt="No Image" class="w-full h-48 object-cover rounded mb-6">
        <?php endif; ?>

        <!-- التفاصيل -->
        <div class="bg-white shadow rounded p-6 space-y-4">
            <p><strong><?php echo e(__('messages.description')); ?>:</strong> <?php echo e($ad->description); ?></p>
            <p><strong><?php echo e(__('messages.price')); ?>:</strong> <?php echo e(number_format($ad->price)); ?> <?php echo e(__('messages.lira')); ?></p>
            <p><strong><?php echo e(__('messages.city')); ?>:</strong> <?php echo e($ad->city); ?></p>
            <p><strong><?php echo e(__('messages.category')); ?>:</strong> <?php echo e($ad->category); ?></p>
            <p><strong><?php echo e(__('messages.created_at')); ?>:</strong> <?php echo e($ad->created_at->diffForHumans()); ?></p>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH /home/delni_user/delni/resources/views/ads/show.blade.php ENDPATH**/ ?>