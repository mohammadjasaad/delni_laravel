<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-7xl mx-auto px-4 py-6">
        <h1 class="text-2xl font-bold mb-6"><?php echo e(__('messages.my_ads')); ?></h1>

        <?php if($ads->count() > 0): ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border rounded-lg overflow-hidden shadow hover:shadow-lg transition bg-white">
                        <?php if($ad->images && count(json_decode($ad->images)) > 0): ?>
                            <img src="<?php echo e(asset('storage/' . json_decode($ad->images)[0])); ?>" alt="Ad Image" class="w-full h-48 object-cover">
                        <?php else: ?>
                            <img src="/placeholder.png" class="w-full h-48 object-cover" alt="default">
                        <?php endif; ?>

                        <div class="p-4 space-y-2">
                            <h3 class="font-bold text-lg"><?php echo e($ad->title); ?></h3>
                            <p class="text-sm text-gray-600"><?php echo e(Str::limit($ad->description, 70)); ?></p>
                            <p class="text-sm text-gray-700"><?php echo e($ad->city); ?> | <?php echo e($ad->category); ?></p>
                            <p class="text-black font-bold"><?php echo e(number_format($ad->price)); ?> <?php echo e(__('messages.lira')); ?></p>

                            <div class="flex justify-between mt-4">
                                <a href="<?php echo e(route('ads.edit', $ad->id)); ?>" class="text-blue-600 hover:underline"><?php echo e(__('messages.edit')); ?></a>
                                <form method="POST" action="<?php echo e(route('ads.destroy', $ad->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:underline"><?php echo e(__('messages.delete')); ?></button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <p class="text-center text-gray-500"><?php echo e(__('messages.no_ads_yet')); ?></p>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/delni_user/delni/resources/views/dashboard/myads.blade.php ENDPATH**/ ?>