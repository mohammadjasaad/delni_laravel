<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-7xl mx-auto px-4 py-6">
        <h1 class="text-2xl font-bold mb-4 text-center"><?php echo e(__('messages.ads')); ?></h1>

        <!-- فلاتر -->
        <form method="GET" action="<?php echo e(route('ads.index')); ?>" class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <select name="city" class="border p-2 rounded">
                <option value=""><?php echo e(__('messages.select_city')); ?></option>
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($city); ?>" <?php echo e(request('city') == $city ? 'selected' : ''); ?>>
                        <?php echo e($city); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <select name="category" class="border p-2 rounded">
                <option value=""><?php echo e(__('messages.select_category')); ?></option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat); ?>" <?php echo e(request('category') == $cat ? 'selected' : ''); ?>>
                        <?php echo e($cat); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <select name="sort" class="border p-2 rounded">
                <option value=""><?php echo e(__('messages.sort_by')); ?></option>
                <option value="latest" <?php echo e(request('sort') == 'latest' ? 'selected' : ''); ?>><?php echo e(__('messages.latest')); ?></option>
                <option value="price_asc" <?php echo e(request('sort') == 'price_asc' ? 'selected' : ''); ?>><?php echo e(__('messages.price_low_to_high')); ?></option>
                <option value="price_desc" <?php echo e(request('sort') == 'price_desc' ? 'selected' : ''); ?>><?php echo e(__('messages.price_high_to_low')); ?></option>
            </select>

            <div>
                <button type="submit" class="bg-yellow-400 px-4 py-2 rounded w-full"><?php echo e(__('messages.filter')); ?></button>
                <a href="<?php echo e(route('ads.index')); ?>" class="text-sm text-gray-600 underline block text-center mt-2"><?php echo e(__('messages.reset')); ?></a>
            </div>
        </form>

        <!-- الإعلانات -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border rounded-lg overflow-hidden shadow hover:shadow-lg transition">
                    <?php if($ad->images && count(json_decode($ad->images)) > 0): ?>
                        <img src="<?php echo e(asset('storage/' . json_decode($ad->images)[0])); ?>" class="w-full h-48 object-cover" alt="ad">
                    <?php else: ?>
                        <img src="/placeholder.png" class="w-full h-48 object-cover" alt="default">
                    <?php endif; ?>
                    <div class="p-4">
                        <h3 class="font-bold text-lg mb-1"><?php echo e($ad->title); ?></h3>
                        <p class="text-gray-600 text-sm"><?php echo e(Str::limit($ad->description, 80)); ?></p>
                        <div class="mt-2 text-sm text-gray-700">
                            <span><?php echo e($ad->city); ?> - <?php echo e($ad->category); ?></span><br>
                            <span class="font-bold text-black"><?php echo e(number_format($ad->price)); ?> <?php echo e(__('messages.lira')); ?></span>
                        </div>
                        <a href="<?php echo e(route('ads.show', $ad->id)); ?>" class="block bg-yellow-400 text-center mt-3 py-2 rounded hover:bg-yellow-300 transition">
                            <?php echo e(__('messages.view_ad')); ?>

                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH /home/delni_user/delni/resources/views/ads/index.blade.php ENDPATH**/ ?>