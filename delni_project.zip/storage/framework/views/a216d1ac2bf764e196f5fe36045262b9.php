<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto py-12 px-4">
    <h1 class="text-3xl font-bold mb-6 text-yellow-600"><?php echo e(__('messages.about_title')); ?></h1>
    
    <div class="text-gray-800 leading-relaxed space-y-4">
        <p><?php echo e(__('messages.about_text_1')); ?></p>
        <p><?php echo e(__('messages.about_text_2')); ?></p>
        <p><?php echo e(__('messages.about_text_3')); ?></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/delni_user/delni/resources/views/about.blade.php ENDPATH**/ ?>