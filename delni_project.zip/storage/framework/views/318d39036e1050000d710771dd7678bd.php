<nav x-data="{ open: false }" class="bg-yellow-400 shadow z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">
            <!-- Logo -->
            <div class="flex-shrink-0 flex items-center">
                <a href="<?php echo e(url('/')); ?>" class="flex items-center">
                    <img src="/logo.png" alt="Delni Logo" class="h-8 w-8 mr-2">
                    <span class="text-black font-bold text-xl">Delni.co</span>
                </a>
            </div>

            <!-- Desktop Menu -->
            <div class="hidden md:flex space-x-4 items-center">
                <a href="<?php echo e(route('ads.index')); ?>" class="text-black hover:text-white"><?php echo e(__('messages.ads')); ?></a>
                <a href="<?php echo e(url('/dashboard/myads')); ?>" class="text-black hover:text-white"><?php echo e(__('messages.my_ads')); ?></a>
                <a href="<?php echo e(url('/dashboard/myinfo')); ?>" class="text-black hover:text-white"><?php echo e(__('messages.my_info')); ?></a>
                <a href="<?php echo e(url('/about')); ?>" class="text-black hover:text-white"><?php echo e(__('messages.about_us')); ?></a>
                <a href="<?php echo e(url('/contact')); ?>" class="text-black hover:text-white"><?php echo e(__('messages.contact_us')); ?></a>
                <?php if(auth()->guard()->check()): ?>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="text-black hover:text-white"><?php echo e(__('messages.logout')); ?></button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="text-black hover:text-white"><?php echo e(__('messages.login')); ?></a>
                <?php endif; ?>
            </div>

            <!-- Hamburger -->
            <div class="md:hidden">
                <button @click="open = !open" class="text-black focus:outline-none">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile Menu -->
    <div x-show="open" class="md:hidden px-4 py-4 space-y-2">
        <a href="<?php echo e(route('ads.index')); ?>" class="block text-black"><?php echo e(__('messages.ads')); ?></a>
        <a href="<?php echo e(url('/dashboard/myads')); ?>" class="block text-black"><?php echo e(__('messages.my_ads')); ?></a>
        <a href="<?php echo e(url('/dashboard/myinfo')); ?>" class="block text-black"><?php echo e(__('messages.my_info')); ?></a>
        <a href="<?php echo e(url('/about')); ?>" class="block text-black"><?php echo e(__('messages.about_us')); ?></a>
        <a href="<?php echo e(url('/contact')); ?>" class="block text-black"><?php echo e(__('messages.contact_us')); ?></a>
        <?php if(auth()->guard()->check()): ?>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="block text-black"><?php echo e(__('messages.logout')); ?></button>
            </form>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="block text-black"><?php echo e(__('messages.login')); ?></a>
        <?php endif; ?>
    </div>
</nav>
<?php /**PATH /home/delni_user/delni/resources/views/partials/header.blade.php ENDPATH**/ ?>