<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function send(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'message' => 'required|string',
        ]);

        // هنا يمكنك لاحقًا إرسال الإيميل أو حفظ الرسالة في قاعدة البيانات

        return redirect()->back()->with('success', __('messages.contact_success'));
    }
}
