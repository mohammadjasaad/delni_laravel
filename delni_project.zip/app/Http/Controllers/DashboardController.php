<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Ad;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function myAds()
    {
        $ads = Ad::where('user_id', Auth::id())->latest()->get();
        return view('dashboard.myads', compact('ads'));
    }
}
