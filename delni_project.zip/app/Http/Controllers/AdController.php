<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Ad;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;

class AdController extends Controller
{
    // صفحة إنشاء إعلان
    public function create()
    {
        return view('ads.create');
    }

    // حفظ الإعلان الجديد
public function store(Request $request)
{
    $validated = $request->validate([
        'title' => 'required|string|max:255',
        'description' => 'required|string',
        'price' => 'required|numeric',
        'city' => 'required|string',
        'category' => 'required|string',
        'images.*' => 'image|mimes:jpeg,png,jpg,gif|max:2048', // التحقق من كل صورة
    ]);

    // ✅ معالجة الصور المتعددة
    $imagePaths = [];

    if ($request->hasFile('images')) {
        foreach ($request->file('images') as $image) {
            $imageName = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('uploads'), $imageName);
            $imagePaths[] = 'uploads/' . $imageName;
        }
    }

    $validated['images'] = json_encode($imagePaths, JSON_UNESCAPED_UNICODE); // تخزينها كـ JSON

    $validated['user_id'] = Auth::id(); // ربط الإعلان بالمستخدم

    Ad::create($validated);

    return redirect('/ads')->with('success', 'تم إنشاء الإعلان بنجاح');
}

    // صفحة عرض جميع الإعلانات
public function index(Request $request)
{
    $query = Ad::query();

    if ($request->has('city') && $request->city != '') {
        $query->where('city', $request->city);
    }

    if ($request->has('category') && $request->category != '') {
        $query->where('category', $request->category);
    }

    if ($request->has('sort')) {
        if ($request->sort == 'price_asc') {
            $query->orderBy('price', 'asc');
        } elseif ($request->sort == 'price_desc') {
            $query->orderBy('price', 'desc');
        } else {
            $query->latest();
        }
    } else {
        $query->latest();
    }

    $ads = $query->get();

    // ✅ هنا نمرّر المتغيرات إلى الـ View
    $cities = ['دمشق', 'حلب', 'حمص', 'حماة', 'اللاذقية', 'طرطوس', 'الرقة', 'دير الزور', 'الحسكة', 'إدلب', 'درعا', 'السويداء', 'القنيطرة', 'ريف دمشق'];
    $categories = ['عقارات', 'سيارات'];

    return view('ads.index', compact('ads', 'cities', 'categories'));
}

    // صفحة تفاصيل إعلان
public function show($id)
{
    $ad = Ad::findOrFail($id);

    // تأكد من تحويل الصور من JSON إلى array إن لم تكن array
    if (!is_array($ad->images)) {
        $ad->images = json_decode($ad->images, true);
    }

    return view('ads.show', compact('ad'));
}

    // صفحة "إعلاناتي"
public function myAds()
{
    $ads = Ad::where('user_id', auth()->id())->get();
    return view('dashboard.myads', compact('ads'));
}
    // صفحة "بياناتي"
    public function myInfo()
    {
        return view('dashboard.myinfo');
    }

    // صفحة تعديل الإعلان
// عرض نموذج تعديل الإعلان
// عرض صفحة التعديل
public function edit($id)
{
    $ad = Ad::findOrFail($id);
    $cities = ['دمشق', 'حلب', 'حمص', 'اللاذقية', 'طرطوس', 'حماة', 'درعا', 'السويداء', 'دير الزور', 'الرقة', 'الحسكة', 'إدلب', 'القنيطرة', 'ريف دمشق'];
    $categories = ['عقارات', 'سيارات'];

    return view('dashboard.edit', compact('ad', 'cities', 'categories'));
}

// تنفيذ التعديل

// حفظ التعديلات
public function update(Request $request, $id)
{
    $ad = Ad::findOrFail($id);

    $validated = $request->validate([
        'title' => 'required|string|max:255',
        'description' => 'required|string',
        'price' => 'required|numeric',
        'city' => 'required|string',
        'category' => 'required|string',
        'images.*' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
    ]);

    // ✅ حذف الصور القديمة إذا تم رفع صور جديدة
    $imagePaths = [];

    if ($request->hasFile('images')) {
        // حذف الصور القديمة من السيرفر (اختياري حسب الحاجة)
        $oldImages = is_array($ad->images) ? $ad->images : json_decode($ad->images, true);
        foreach ($oldImages as $old) {
            if (file_exists(public_path($old))) {
                @unlink(public_path($old));
            }
        }

        // رفع الصور الجديدة
        foreach ($request->file('images') as $image) {
            $imageName = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('uploads'), $imageName);
            $imagePaths[] = 'uploads/' . $imageName;
        }

        $validated['images'] = json_encode($imagePaths, JSON_UNESCAPED_UNICODE);
    }

    $ad->update($validated);

    return redirect()->route('dashboard.myads')->with('success', 'تم تحديث الإعلان بنجاح');
}

    // حذف الإعلان
public function destroy($id)
{
    $ad = Ad::where('id', $id)->where('user_id', auth()->id())->firstOrFail();

    // حذف الصور من التخزين (اختياري)
    if ($ad->images) {
        foreach (json_decode($ad->images) as $image) {
            \Storage::disk('public')->delete($image);
        }
    }

    $ad->delete();

    return redirect()->route('dashboard.myads')->with('success', __('messages.ad_deleted_successfully'));
}

}
