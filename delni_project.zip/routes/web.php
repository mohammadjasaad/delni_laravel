<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdController;
use App\Http\Controllers\DashboardController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/contact', function () {
    return view('contact');
})->name('contact');

Route::get('/about', function () {
    return view('about');
})->name('about');

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
Route::get('/ads', [AdController::class, 'index'])->name('ads.index');
Route::get('/ads/{id}', [AdController::class, 'show'])->name('ads.show');
Route::get('/dashboard/myads', [AdController::class, 'myAds'])->middleware(['auth'])->name('dashboard.myads');
Route::get('/dashboard/create', [AdController::class, 'create'])->name('dashboard.create');
Route::post('/dashboard/store', [AdController::class, 'store'])->name('ads.store');
Route::put('/dashboard/update/{id}', [AdController::class, 'update'])->name('dashboard.update');
Route::get('/dashboard/myinfo', [DashboardController::class, 'myinfo'])->name('dashboard.myinfo');
Route::get('/dashboard/myads', [DashboardController::class, 'myAds'])->name('dashboard.myads');
Route::get('/dashboard/ads/{id}/edit', [AdController::class, 'edit'])->name('dashboard.ads.edit');

});

require __DIR__.'/auth.php';
Route::put('/dashboard/ads/{id}', [AdController::class, 'update'])->name('ads.update');
Route::delete('/dashboard/ads/{id}', [AdController::class, 'destroy'])->name('ads.destroy');
