<x-guest-layout>
    <div class="max-w-4xl mx-auto py-12 px-6">
        <h1 class="text-3xl font-bold mb-6">{{ __('messages.about_title') }}</h1>
        <p class="text-lg leading-relaxed text-gray-700">
            {{ __('messages.about_description') }}
        </p>
    </div>
</x-guest-layout>
