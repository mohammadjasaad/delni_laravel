<header x-data="{ open: false }" class="bg-yellow-400 shadow z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">
            <!-- الشعار -->
            <div class="flex-shrink-0 flex items-center">
                <a href="{{ url('/') }}">
                    <img src="/logo.png" alt="Delni Logo" class="h-8 w-auto">
                </a>
                <span class="text-black font-bold text-xl ml-2">Delni.co</span>
            </div>

            <!-- القائمة على الديسكتوب -->
            <div class="hidden md:flex space-x-4 items-center rtl:space-x-reverse">
                <a href="{{ route('ads.index') }}" class="text-black hover:text-white">{{ __('messages.ads') }}</a>
                <a href="{{ route('dashboard.myads') }}" class="text-black hover:text-white">{{ __('messages.my_ads') }}</a>
                <a href="{{ route('dashboard.myinfo') }}" class="text-black hover:text-white">{{ __('messages.my_info') }}</a>
                <a href="{{ url('/about') }}" class="text-black hover:text-white">{{ __('messages.about_us') }}</a>
                <a href="{{ url('/contact') }}" class="text-black hover:text-white">{{ __('messages.contact_us') }}</a>

                @auth
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit" class="text-black hover:text-white">{{ __('messages.logout') }}</button>
                    </form>
                @else
                    <a href="{{ route('login') }}" class="text-black hover:text-white">{{ __('messages.login') }}</a>
                @endauth
            </div>

            <!-- زر القائمة للموبايل -->
            <div class="md:hidden">
                <button @click="open = !open" class="text-black focus:outline-none">
                    <svg class="h-6 w-6 fill-current" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <!-- قائمة الموبايل -->
    <div x-show="open" class="md:hidden px-4 py-4 space-y-2">
        <a href="{{ route('ads.index') }}" class="block text-black">{{ __('messages.ads') }}</a>
        <a href="{{ route('dashboard.myads') }}" class="block text-black">{{ __('messages.my_ads') }}</a>
        <a href="{{ route('dashboard.myinfo') }}" class="block text-black">{{ __('messages.my_info') }}</a>
        <a href="{{ url('/about') }}" class="block text-black">{{ __('messages.about_us') }}</a>
        <a href="{{ url('/contact') }}" class="block text-black">{{ __('messages.contact_us') }}</a>

        @auth
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="block text-black">{{ __('messages.logout') }}</button>
            </form>
        @else
            <a href="{{ route('login') }}" class="block text-black">{{ __('messages.login') }}</a>
        @endauth
    </div>
</header>
