<footer class="bg-gray-800 text-white py-6 mt-10">
    <div class="max-w-7xl mx-auto px-4 text-center">
        <p>&copy; {{ date('Y') }} Delni.co. {{ __('messages.all_rights_reserved') }}</p>
        <p class="mt-2 text-sm">
            <a href="{{ url('/about') }}" class="hover:underline">{{ __('messages.about_us') }}</a> |
            <a href="{{ url('/contact') }}" class="hover:underline">{{ __('messages.contact_us') }}</a>
        </p>
    </div>
</footer>
