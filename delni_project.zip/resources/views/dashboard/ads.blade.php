<x-app-layout>
    <div class="max-w-7xl mx-auto py-10">
        <h1 class="text-2xl font-bold mb-4">🗂️ إعلاناتي</h1>

        @foreach($ads as $ad)
            <div class="bg-white rounded shadow p-4 mb-4">
                <h2 class="text-xl font-semibold">{{ $ad->title }}</h2>
                <p class="text-gray-700">{{ $ad->description }}</p>
                <p><strong>السعر:</strong> {{ number_format($ad->price) }} ليرة</p>
                <p><strong>المدينة:</strong> {{ $ad->city }}</p>

                <div class="flex space-x-2 mt-4">
                    <a href="{{ route('dashboard.ads.edit', $ad->id) }}" class="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded">
                        ✏️ تعديل الإعلان
                    </a>
                    <form action="{{ route('ads.destroy', $ad->id) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button onclick="return confirm('هل أنت متأكد من حذف الإعلان؟')" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded">
                            🗑️ حذف الإعلان
                        </button>
                    </form>
                </div>
            </div>
        @endforeach
    </div>
</x-app-layout>
