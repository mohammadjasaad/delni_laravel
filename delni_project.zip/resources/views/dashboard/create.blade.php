<x-app-layout>
    <div class="max-w-3xl mx-auto py-8 px-4">
        <h1 class="text-2xl font-bold mb-6">{{ __('messages.add_ad') }}</h1>

        <form method="POST" action="{{ route('ads.store') }}" enctype="multipart/form-data" class="space-y-6">
            @csrf

            <div>
                <label class="block font-medium mb-1">{{ __('messages.title') }}</label>
                <input type="text" name="title" class="w-full border rounded px-4 py-2" required>
            </div>

            <div>
                <label class="block font-medium mb-1">{{ __('messages.description') }}</label>
                <textarea name="description" class="w-full border rounded px-4 py-2" rows="4" required></textarea>
            </div>

            <div>
                <label class="block font-medium mb-1">{{ __('messages.price') }}</label>
                <input type="number" name="price" class="w-full border rounded px-4 py-2" required>
            </div>

            <div>
                <label class="block font-medium mb-1">{{ __('messages.city') }}</label>
                <select name="city" class="w-full border rounded px-4 py-2" required>
                    <option value="">{{ __('messages.select_city') }}</option>
                    @foreach($cities as $city)
                        <option value="{{ $city }}">{{ $city }}</option>
                    @endforeach
                </select>
            </div>

            <div>
                <label class="block font-medium mb-1">{{ __('messages.category') }}</label>
                <select name="category" class="w-full border rounded px-4 py-2" required>
                    <option value="">{{ __('messages.select_category') }}</option>
                    @foreach($categories as $category)
                        <option value="{{ $category }}">{{ $category }}</option>
                    @endforeach
                </select>
            </div>

            <div>
                <label class="block font-medium mb-1">{{ __('messages.upload_images') }}</label>
                <input type="file" name="images[]" multiple class="w-full border rounded px-4 py-2">
                <p class="text-sm text-gray-500 mt-1">{{ __('messages.multiple_images_note') }}</p>
            </div>

            <button type="submit" class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded">
                {{ __('messages.add') }}
            </button>
        </form>
    </div>
</x-app-layout>
