@extends('layouts.app')

@section('content')
<div class="container">
    <h1 class="mb-4">👤 بياناتي</h1>

    <div class="card">
        <div class="card-body">
            <p><strong>مرحباً بك زائر في حسابك.</strong></p>
            <p>📧 البريد الإلكتروني: غير متوفر</p>
            <p>📅 تاريخ الانضمام: غير متوفر</p>
        </div>
    </div>
</div>
@endsection
