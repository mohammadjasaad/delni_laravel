<x-app-layout>
    <div class="max-w-7xl mx-auto py-10 px-4">
        <h1 class="text-2xl font-bold mb-6">📋 {{ __('messages.my_ads') }}</h1>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @foreach($ads as $ad)
                @php
                    $images = is_array($ad->images) ? $ad->images : json_decode($ad->images, true);
                    $firstImage = $images[0] ?? 'placeholder.png';
                @endphp

                <div class="border rounded shadow hover:shadow-lg transition bg-white">
                    <img src="{{ asset($firstImage) }}" alt="Ad Image" class="w-full h-48 object-cover rounded-t">

                    <div class="p-4">
                        <h2 class="text-lg font-bold mb-1">{{ $ad->title }}</h2>
                        <p class="text-sm text-gray-600 mb-2">{{ Str::limit($ad->description, 60) }}</p>

                        <div class="text-sm text-gray-500 mb-1">
                            {{ $ad->city }} | {{ $ad->category }}
                        </div>
                        <div class="font-bold text-black mb-2">
                            {{ number_format($ad->price) }} {{ __('messages.lira') }}
                        </div>

                        <div class="flex justify-between">
                            <a href="{{ route('ads.edit', $ad->id) }}" class="text-sm text-yellow-600 hover:underline">
                                ✏️ {{ __('messages.edit') }}
                            </a>
                            <form method="POST" action="{{ route('ads.destroy', $ad->id) }}">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-sm text-red-600 hover:underline">
                                    🗑️ {{ __('messages.delete') }}
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</x-app-layout>
