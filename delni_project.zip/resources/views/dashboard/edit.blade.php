<x-app-layout>
    <div class="max-w-3xl mx-auto py-8 px-4">
        <h1 class="text-2xl font-bold mb-6">{{ __('messages.edit_ad') }}</h1>

        <form method="POST" action="{{ route('ads.update', $ad->id) }}" enctype="multipart/form-data" class="space-y-6">
            @csrf
            @method('PUT')

            <div>
                <label class="block font-medium mb-1">{{ __('messages.title') }}</label>
                <input type="text" name="title" value="{{ $ad->title }}" class="w-full border rounded px-4 py-2" required>
            </div>

            <div>
                <label class="block font-medium mb-1">{{ __('messages.description') }}</label>
                <textarea name="description" class="w-full border rounded px-4 py-2" rows="4" required>{{ $ad->description }}</textarea>
            </div>

            <div>
                <label class="block font-medium mb-1">{{ __('messages.price') }}</label>
                <input type="number" name="price" value="{{ $ad->price }}" class="w-full border rounded px-4 py-2" required>
            </div>

            <div>
                <label class="block font-medium mb-1">{{ __('messages.city') }}</label>
                <select name="city" class="w-full border rounded px-4 py-2" required>
                    @foreach($cities as $city)
                        <option value="{{ $city }}" @if($ad->city == $city) selected @endif>{{ $city }}</option>
                    @endforeach
                </select>
            </div>

            <div>
                <label class="block font-medium mb-1">{{ __('messages.category') }}</label>
                <select name="category" class="w-full border rounded px-4 py-2" required>
                    @foreach($categories as $category)
                        <option value="{{ $category }}" @if($ad->category == $category) selected @endif>{{ $category }}</option>
                    @endforeach
                </select>
            </div>

            <div>
                <label class="block font-medium mb-1">{{ __('messages.upload_new_images') }}</label>
                <input type="file" name="images[]" multiple class="w-full border rounded px-4 py-2">
                <p class="text-sm text-gray-500 mt-1">{{ __('messages.replace_note') }}</p>

                @if($ad->images)
                    <div class="grid grid-cols-2 gap-4 mt-4">
                        @foreach($ad->images as $image)
                            <img src="{{ asset($image) }}" alt="Current Image" class="w-full h-32 object-cover rounded">
                        @endforeach
                    </div>
                @endif
            </div>

            <button type="submit" class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded">
                {{ __('messages.update_ad') }}
            </button>
        </form>
    </div>
</x-app-layout>
