@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6">

    {{-- مربع البحث --}}
    <div class="mb-6">
        <input type="text" placeholder="ابحث عن عقار أو سيارة"
               class="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring focus:ring-yellow-400">
    </div>

    {{-- أقسام رئيسية --}}
    <div class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-6 text-center mb-10">
        <a href="{{ url('/ads?category=عقارات') }}" class="flex flex-col items-center hover:scale-105 transition-transform">
            <img src="https://cdn-icons-png.flaticon.com/512/69/69524.png" class="w-20 h-20 mb-2" alt="عقارات">
            <span class="font-semibold">عقارات</span>
        </a>

        <a href="{{ url('/ads?category=سيارات') }}" class="flex flex-col items-center hover:scale-105 transition-transform">
            <img src="https://cdn-icons-png.flaticon.com/512/743/743007.png" class="w-20 h-20 mb-2" alt="سيارات">
            <span class="font-semibold">سيارات</span>
        </a>
    </div>

    {{-- أحدث الإعلانات --}}
    <h2 class="text-xl font-bold mb-4">أحدث الإعلانات</h2>

    <div class="grid gap-4">
        @foreach ($latestAds as $ad)
            <div class="bg-white rounded-lg shadow-md p-4 flex items-center gap-4">
                <img src="{{ $ad->images[0] ?? '/images/placeholder.png' }}" class="w-24 h-24 object-cover rounded-md" alt="إعلان">

                <div class="flex-1">
                    <h3 class="text-lg font-semibold">{{ $ad->title }}</h3>
                    <p class="text-sm text-gray-600">{{ $ad->category }} - {{ $ad->city }}</p>
                    <p class="text-green-600 font-bold mt-1">{{ number_format($ad->price) }} ل.س</p>
                    <a href="{{ route('ads.show', $ad->id) }}"
                       class="text-blue-600 font-semibold hover:underline whitespace-nowrap block mt-2">
                        عرض الإعلان
                    </a>
                </div>
            </div>
        @endforeach
    </div>
</div>
@endsection
