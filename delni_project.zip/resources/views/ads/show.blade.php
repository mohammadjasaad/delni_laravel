<x-guest-layout>
    <div class="max-w-5xl mx-auto px-4 py-8">
        <h1 class="text-2xl font-bold mb-4">{{ $ad->title }}</h1>

        @if(is_array($ad->images) && count($ad->images) > 0)
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                @foreach($ad->images as $image)
                    <img src="{{ asset($image) }}" alt="Ad Image" class="w-full h-48 object-cover rounded">
                @endforeach
            </div>
        @else
            <img src="/placeholder.png" alt="No Image" class="w-full h-48 object-cover rounded mb-4">
        @endif

        <div class="bg-white shadow rounded p-6 space-y-4">
            <p><strong>{{ __('messages.description') }}:</strong> {{ $ad->description }}</p>
            <p><strong>{{ __('messages.price') }}:</strong> {{ number_format($ad->price) }} {{ __('messages.lira') }}</p>
            <p><strong>{{ __('messages.city') }}:</strong> {{ $ad->city }}</p>
            <p><strong>{{ __('messages.category') }}:</strong> {{ $ad->category }}</p>
            <p><strong>{{ __('messages.created_at') }}:</strong> {{ $ad->created_at->diffForHumans() }}</p>
        </div>
    </div>
</x-guest-layout>
