@extends('layouts.app')

@section('content')
<div class="max-w-3xl mx-auto px-4 py-8">
    <h1 class="text-2xl font-bold text-gray-800 mb-6 text-center">إضافة إعلان جديد</h1>

    @if ($errors->any())
        <div class="bg-red-100 text-red-700 p-4 rounded mb-4">
            <ul class="list-disc pl-6">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ route('ads.store') }}" enctype="multipart/form-data" class="bg-white p-6 rounded shadow">
        @csrf

        <div class="mb-4">
            <label for="title" class="block text-gray-700 font-medium mb-1">عنوان الإعلان</label>
            <input type="text" name="title" id="title" value="{{ old('title') }}" required
                class="form-input w-full border rounded px-3 py-2" />
        </div>

        <div class="mb-4">
            <label for="description" class="block text-gray-700 font-medium mb-1">الوصف</label>
            <textarea name="description" id="description" rows="4" required
                class="form-textarea w-full border rounded px-3 py-2">{{ old('description') }}</textarea>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
                <label for="price" class="block text-gray-700 font-medium mb-1">السعر</label>
                <input type="number" name="price" id="price" value="{{ old('price') }}" required
                    class="form-input w-full border rounded px-3 py-2" />
            </div>

            <div>
                <label for="city" class="block text-gray-700 font-medium mb-1">المدينة</label>
                <input type="text" name="city" id="city" value="{{ old('city') }}" required
                    class="form-input w-full border rounded px-3 py-2" />
            </div>
        </div>

        <div class="mb-4">
            <label for="category" class="block text-gray-700 font-medium mb-1">التصنيف</label>
            <select name="category" id="category" required
                class="form-select w-full border rounded px-3 py-2">
                <option value="">اختر تصنيف</option>
                <option value="عقارات" {{ old('category') == 'عقارات' ? 'selected' : '' }}>عقارات</option>
                <option value="سيارات" {{ old('category') == 'سيارات' ? 'selected' : '' }}>سيارات</option>
            </select>
        </div>

        <div class="mb-4">
            <label for="images[]" class="block text-gray-700 font-medium mb-1">صور الإعلان (يمكنك اختيار أكثر من صورة)</label>
            <input type="file" name="images[]" multiple accept="image/*"
                class="form-input w-full border rounded px-3 py-2" />
        </div>

        <button type="submit"
            class="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-6 rounded">
            نشر الإعلان
        </button>
    </form>
</div>
@endsection
