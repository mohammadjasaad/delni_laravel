@include('partials.header')

<x-guest-layout>
    <div class="max-w-7xl mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold text-center mb-6">{{ __('messages.ads') }}</h1>

        <!-- عرض الإعلانات -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            @foreach ($ads as $ad)
                @php
                    $images = is_array($ad->images) ? $ad->images : json_decode($ad->images, true);
                    $firstImage = $images[0] ?? 'placeholder.png';
                @endphp

                <div class="bg-white shadow-md rounded overflow-hidden hover:shadow-xl transition duration-300">
                    <img src="{{ asset('storage/' . $firstImage) }}" alt="Ad Image" class="w-full h-48 object-cover">

                    <div class="p-4 space-y-2">
                        <h2 class="text-xl font-bold">{{ $ad->title }}</h2>
                        <p class="text-gray-600 text-sm">{{ $ad->city }} | {{ $ad->category }}</p>
                        <p class="text-yellow-600 font-bold text-lg">
                            {{ number_format($ad->price) }} {{ __('messages.lira') }}
                        </p>
                        <a href="{{ route('ads.show', $ad->id) }}"
                           class="block text-center bg-yellow-400 hover:bg-yellow-500 text-white font-semibold py-2 rounded">
                            {{ __('messages.view_ad') }}
                        </a>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</x-guest-layout>

@include('partials.footer')
