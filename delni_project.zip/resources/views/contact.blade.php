<x-guest-layout>
    <div class="max-w-4xl mx-auto py-12 px-6">
        <h1 class="text-3xl font-bold mb-6">{{ __('messages.contact_title') }}</h1>
        <p class="text-lg text-gray-700 mb-4">{{ __('messages.contact_description') }}</p>

        <ul class="space-y-2 text-gray-600">
            <li><strong>{{ __('messages.email') }}:</strong> support@delni.co</li>
            <li><strong>{{ __('messages.phone') }}:</strong> +963 988 779 548</li>
            <li><strong>{{ __('messages.address') }}:</strong> دمشق - سوريا</li>
        </ul>
    </div>
</x-guest-layout>
