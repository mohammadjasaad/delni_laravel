@extends("layouts.app")
@section("content")
<h1>✔️ Laravel يعمل بشكل صحيح</h1>
@endsection
